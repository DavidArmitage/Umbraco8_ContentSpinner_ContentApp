﻿
angular.module("umbraco")
    .controller("My.ContentSpinner", function ($http, $scope) {

        var vm = this;
        vm.IsTestMode = false;
        vm.Loading = false;

        var clipboard = new ClipboardJS('#ContentSpinner_CopyToClipboard');

        $http({
            method: "GET",
            url: "/Umbraco/ContentSpinner/ContentSpinner/IsTestMode"
        }).then(function mySuccess(response) {
            vm.IsTestMode = response.data;
        });

        $scope.SpinContent = function () {

            vm.Loading = true;
            vm.ErrorMessage = '';
            var url = "/Umbraco/ContentSpinner/ContentSpinner/SpinContent";

            $http({
                method: "POST",
                url: url,
                data: {
                    OrigionalText: vm.OrigionalText
                },
            }).then(function successCallback(response) {
                vm.Loading = false;
                var data = angular.fromJson(response.data);
                vm.SpunText = data.SpunText;
                vm.ErrorMessage = data.ErrorMessage;
            }, function errorCallback() {
                vm.Loading = false;
                vm.ErrorMessage = "Sorry there was a generic error. If this continues to happen please notify support for a fix.";
            });
        };
    });
